from __future__ import annotations

import json
import os
import shutil
import sys
import subprocess
import tempfile
import threading
import webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

APP_TITLE = "NPV Tunnel Configuration Decoder"
TELEGRAM_URL = "https://t.me/sahandsoft"


def app_directory() -> Path:
    """Directory beside the script or the packaged EXE."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def find_pantegnos() -> Path | None:
    """Find the bundled Pantegnos CLI without asking the user to browse for it."""
    root = app_directory()
    candidates = [
        root / "tools" / "pantegnos.exe",
        root / "pantegnos.exe",
        root / "_internal" / "tools" / "pantegnos.exe",
        Path(getattr(sys, "_MEIPASS", root)) / "tools" / "pantegnos.exe",
    ]
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None


def inspect_file(path: Path) -> dict:
    data = path.read_bytes()
    if data.startswith(b"NPVS"):
        detected = "NPVS binary container"
    elif data.startswith(b"NPVT1"):
        detected = "NPVT1 container"
    elif data.startswith(b"NPVTSUB1"):
        detected = "NPVTSUB1 container"
    elif data.lstrip().startswith((b"{", b"[")):
        detected = "Possible JSON"
    else:
        detected = "Unknown binary/text format"

    printable = sum(1 for b in data if b in (9, 10, 13) or 32 <= b <= 126)
    strings, current = [], bytearray()
    for b in data:
        if 32 <= b <= 126:
            current.append(b)
        else:
            if len(current) >= 5:
                strings.append(current.decode("ascii", errors="replace"))
            current.clear()
    if len(current) >= 5:
        strings.append(current.decode("ascii", errors="replace"))

    try:
        data.decode("utf-8")
        utf8_status = "Valid UTF-8"
    except UnicodeDecodeError:
        utf8_status = "Not plain UTF-8"

    return {
        "size": len(data),
        "detected": detected,
        "head_hex": data[:32].hex(" "),
        "utf8": utf8_status,
        "printable_ratio": printable / max(1, len(data)),
        "strings": strings[:100],
    }


class DecoderApp:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("1050x720")
        self.root.minsize(780, 520)
        self.root.configure(bg="#f2f4f7")
        self.current_file: Path | None = None
        self.dark = False
        self._build_ui()
        self._apply_theme()

    def _build_ui(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        top = ttk.Frame(self.root, padding=(14, 12))
        top.pack(fill="x")
        ttk.Label(top, text=APP_TITLE, font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Button(top, text="About", command=self.show_about).pack(side="right", padx=(6, 0))
        ttk.Button(top, text="Light / Dark", command=self.toggle_theme).pack(side="right")

        toolbar = ttk.Frame(self.root, padding=(14, 0, 14, 10))
        toolbar.pack(fill="x")
        ttk.Button(toolbar, text="Open .npvs file", command=self.open_file).pack(side="left")
        ttk.Button(toolbar, text="Analyze file", command=self.analyze_file).pack(side="left", padx=6)
        ttk.Button(toolbar, text="Copy all", command=self.copy_all).pack(side="left", padx=6)
        ttk.Button(toolbar, text="Save output", command=self.save_output).pack(side="left")
        ttk.Button(toolbar, text="Clear", command=self.clear_output).pack(side="left", padx=6)

        self.file_label = ttk.Label(self.root, text="No file selected", padding=(15, 4))
        self.file_label.pack(fill="x")

        paned = ttk.Panedwindow(self.root, orient="vertical")
        paned.pack(fill="both", expand=True, padx=14, pady=(4, 8))

        info_frame = ttk.Labelframe(paned, text="File diagnostics", padding=8)
        self.info_box = tk.Text(info_frame, height=8, wrap="word", font=("Consolas", 10), relief="flat")
        self.info_box.pack(fill="both", expand=True)
        self.info_box.insert("1.0", "Open an NPVS file to inspect its signature.")
        self.info_box.configure(state="disabled")
        paned.add(info_frame, weight=1)

        output_frame = ttk.Labelframe(paned, text="Decoded configuration", padding=8)
        self.output = tk.Text(output_frame, wrap="none", undo=True, font=("Consolas", 10), padx=8, pady=8)
        yscroll = ttk.Scrollbar(output_frame, orient="vertical", command=self.output.yview)
        xscroll = ttk.Scrollbar(output_frame, orient="horizontal", command=self.output.xview)
        self.output.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.output.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        output_frame.rowconfigure(0, weight=1)
        output_frame.columnconfigure(0, weight=1)
        paned.add(output_frame, weight=3)

        footer = ttk.Frame(self.root, padding=(14, 4, 14, 10))
        footer.pack(fill="x")
        self.credit = tk.Label(footer, text="سازنده: دانیال افشاری | تلگرام: sahandsoft",
                               cursor="hand2", fg="#1769aa", bg="#f2f4f7",
                               font=("Segoe UI", 9, "underline"))
        self.credit.pack(side="left")
        self.credit.bind("<Button-1>", lambda _e: webbrowser.open(TELEGRAM_URL))
        ttk.Label(footer, textvariable=self.status).pack(side="right")

    @property
    def status(self):
        if not hasattr(self, "_status"):
            self._status = tk.StringVar(value="Ready")
        return self._status

    def _apply_theme(self):
        bg = "#20242b" if self.dark else "#f2f4f7"
        fg = "#e8eaed" if self.dark else "#202124"
        text_bg = "#171a1f" if self.dark else "#ffffff"
        self.root.configure(bg=bg)
        self.output.configure(bg=text_bg, fg=fg, insertbackground=fg)
        self.info_box.configure(bg=text_bg, fg=fg)
        self.credit.configure(bg=bg, fg="#8ab4f8" if self.dark else "#1769aa")

    def toggle_theme(self):
        self.dark = not self.dark
        self._apply_theme()

    def open_file(self):
        name = filedialog.askopenfilename(
            title="Select an NPV Tunnel file",
            filetypes=[("NPV Tunnel files", "*.npvs *.npvt"), ("All files", "*.*")]
        )
        if name:
            self.current_file = Path(name)
            self.file_label.configure(text=f"Selected: {self.current_file}")
            self.analyze_file()
            self.decode_file()

    def analyze_file(self):
        if not self.current_file:
            messagebox.showinfo(APP_TITLE, "First select an .npvs file.")
            return
        try:
            info = inspect_file(self.current_file)
            report = [
                f"File: {self.current_file.name}",
                f"Size: {info['size']:,} bytes",
                f"Detected structure: {info['detected']}",
                f"Text check: {info['utf8']}",
                f"Printable-byte ratio: {info['printable_ratio']:.1%}",
                f"First 32 bytes (hex): {info['head_hex']}",
                "",
                "Readable ASCII fragments (not necessarily meaningful):",
                *[f"  {s}" for s in info["strings"][:30]],
                "",
                "Signature detection does not decrypt the configuration."
            ]
            self.info_box.configure(state="normal")
            self.info_box.delete("1.0", "end")
            self.info_box.insert("1.0", "\n".join(report))
            self.info_box.configure(state="disabled")
            self.output.delete("1.0", "end")
            self.output.insert("1.0",
                "File analyzed. Automatic decoding starts when a file is opened.\n\n"
                "If decoding is unsuccessful, check the Pantegnos console window and confirm "
                "that the file format and passphrase are supported.")
            self.status.set("Analysis complete")
        except OSError as exc:
            messagebox.showerror(APP_TITLE, f"Could not read the file:\n{exc}")
            self.status.set("Read failed")

    def decode_file(self):
        if not self.current_file:
            messagebox.showinfo(APP_TITLE, "First select an .npvs file.")
            return

        exe_path = find_pantegnos()
        if exe_path is None:
            messagebox.showerror(
                APP_TITLE,
                "Pantegnos was not found.\n\n"
                "Keep the tools folder beside main.py or beside NPVSDecoder.exe:\n"
                "tools\\pantegnos.exe\n\n"
                "The downloadable project ZIP already includes this tool."
            )
            self.status.set("Pantegnos missing")
            return

        work_root = Path(tempfile.mkdtemp(prefix="npvs-decode-"))
        input_dir = work_root / "input"
        output_dir = work_root / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        shutil.copy2(self.current_file, input_dir / self.current_file.name)

        self.output.delete("1.0", "end")
        self.output.insert("1.0", "Decoding locally with bundled Pantegnos...\n")
        self.status.set("Decoding...")

        def worker():
            try:
                # Pantegnos accepts directories for both -input and -output.
                # On Windows, use a separate console so its secure passphrase prompt,
                # when needed, has a real terminal to read from.
                kwargs = dict(
                    args=[str(exe_path), "-input", str(input_dir), "-output", str(output_dir)],
                    timeout=300,
                    check=False,
                )
                if os.name == "nt":
                    kwargs["creationflags"] = subprocess.CREATE_NEW_CONSOLE
                    proc = subprocess.run(**kwargs)
                    stdout = ""
                    stderr = ""
                else:
                    proc = subprocess.run(
                        **kwargs, capture_output=True, text=True
                    )
                    stdout, stderr = proc.stdout, proc.stderr

                output_files = [p for p in output_dir.rglob("*") if p.is_file()]
                blocks = []
                for out_file in output_files:
                    try:
                        content = out_file.read_text(encoding="utf-8")
                    except UnicodeDecodeError:
                        content = out_file.read_text(encoding="utf-8", errors="replace")
                    blocks.append(f"===== {out_file.name} =====\n{content}")

                if blocks:
                    display = "\n\n".join(blocks)
                    status = "Decoded output loaded"
                else:
                    display = (
                        "Pantegnos finished, but no decoded output file was created.\n\n"
                        f"Exit code: {proc.returncode}\n\n"
                        f"STDOUT:\n{stdout[-6000:] or '(empty; on Windows, see the Pantegnos console window)'}\n\n"
                        f"STDERR:\n{stderr[-6000:] or '(empty; on Windows, see the Pantegnos console window)'}\n\n"
                        "If a passphrase prompt appeared, enter the correct passphrase in the "
                        "Pantegnos console window. If no prompt appeared, check the console "
                        "message and confirm this file is supported by the bundled Pantegnos version."
                    )
                    status = "No output; check Pantegnos console"
                self.root.after(0, lambda d=display, s=status: self._show_result(d, s))
            except subprocess.TimeoutExpired:
                self.root.after(0, lambda: self._show_result(
                    "Pantegnos timed out after 300 seconds.", "Decoder timeout"))
            except OSError as exc:
                self.root.after(0, lambda e=str(exc): self._show_result(
                    f"Could not launch bundled Pantegnos:\n{e}", "Decoder launch failed"))

        threading.Thread(target=worker, daemon=True).start()

    def _show_result(self, display, status):
        self.output.delete("1.0", "end")
        self.output.insert("1.0", display)
        self.status.set(status)

    def copy_all(self):
        content = self.output.get("1.0", "end-1c")
        if content:
            self.root.clipboard_clear()
            self.root.clipboard_append(content)
            self.status.set("Copied to clipboard")

    def save_output(self):
        content = self.output.get("1.0", "end-1c")
        if not content:
            messagebox.showinfo(APP_TITLE, "There is no output to save.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("JSON files", "*.json"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            target = Path(path)
            if target.suffix.lower() == ".json":
                try:
                    content = json.dumps(json.loads(content), ensure_ascii=False, indent=2)
                except json.JSONDecodeError:
                    messagebox.showwarning(APP_TITLE, "Output is not valid JSON; saving as text.")
            target.write_text(content, encoding="utf-8")
            self.status.set(f"Saved {target.name}")
        except OSError as exc:
            messagebox.showerror(APP_TITLE, f"Could not save output:\n{exc}")

    def clear_output(self):
        self.output.delete("1.0", "end")
        self.status.set("Output cleared")

    def show_about(self):
        win = tk.Toplevel(self.root)
        win.title("About")
        frame = ttk.Frame(win, padding=20)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text=APP_TITLE, font=("Segoe UI", 13, "bold")).pack(pady=(0, 10))
        ttk.Label(frame, text="Local NPVS analysis and decoder interface").pack()
        ttk.Label(frame, text="سازنده: دانیال افشاری").pack(pady=(12, 2))
        link = tk.Label(frame, text="تلگرام: sahandsoft", fg="#1769aa", cursor="hand2",
                        font=("Segoe UI", 10, "underline"))
        link.pack()
        link.bind("<Button-1>", lambda _e: webbrowser.open(TELEGRAM_URL))
        ttk.Label(frame, text="Decoded configurations may contain sensitive credentials.",
                  wraplength=340).pack(pady=(12, 0))


def main():
    root = tk.Tk()
    DecoderApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
