@echo off
setlocal
cd /d "%~dp0"

echo ==============================================
echo  NPVS Decoder - Windows portable EXE builder
echo ==============================================
echo.
where py >nul 2>nul
if errorlevel 1 (
  echo ERROR: Python Launcher (py) was not found.
  echo Install Python 3.10 or newer only for building this package.
  echo The generated portable folder will not need Python installed.
  pause
  exit /b 1
)

py -m pip install --upgrade pyinstaller
if errorlevel 1 goto fail

if exist "build" rmdir /s /q "build"
if exist "dist" rmdir /s /q "dist"
if exist "Portable_EXE" rmdir /s /q "Portable_EXE"

py -m PyInstaller --noconfirm --clean --onefile --windowed --name NPVSDecoder main.py
if errorlevel 1 goto fail

mkdir "Portable_EXE\tools"
copy /Y "dist\NPVSDecoder.exe" "Portable_EXE\NPVSDecoder.exe" >nul
copy /Y "tools\pantegnos.exe" "Portable_EXE\tools\pantegnos.exe" >nul
copy /Y "tools\LICENSE" "Portable_EXE\tools\LICENSE" >nul
copy /Y "tools\PANTEGNOS_README.md" "Portable_EXE\tools\PANTEGNOS_README.md" >nul
if errorlevel 1 goto fail

(
  echo NPVS Decoder - Portable Windows build
  echo.
  echo Run NPVSDecoder.exe. No separate Python installation is needed.
  echo Keep the tools folder beside NPVSDecoder.exe because it contains the decoder engine.
  echo If the NPVS file requires a passphrase, a console prompt may appear.
  echo Pantegnos license and notices are included in tools\.
) > "Portable_EXE\README.txt"

echo.
echo BUILD SUCCESSFUL.
echo Portable app folder: %CD%\Portable_EXE
echo Copy the entire Portable_EXE folder to another Windows PC.
echo Do not copy only NPVSDecoder.exe; tools\pantegnos.exe is required.
echo.
explorer "%CD%\Portable_EXE"
pause
exit /b 0

:fail
echo.
echo BUILD FAILED. Read the error above.
pause
exit /b 1
