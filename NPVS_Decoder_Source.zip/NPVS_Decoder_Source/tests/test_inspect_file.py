import tempfile
import unittest
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from main import inspect_file


class InspectTests(unittest.TestCase):
    def test_npvs_signature(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "x.npvs"
            p.write_bytes(b"NPVS\x00\x01\x02")
            self.assertEqual(inspect_file(p)["detected"], "NPVS binary container")

    def test_json_signature(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "x.dat"
            p.write_text('{"hello": "world"}', encoding="utf-8")
            self.assertEqual(inspect_file(p)["detected"], "Possible JSON")

    def test_empty_file(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "empty"
            p.write_bytes(b"")
            self.assertEqual(inspect_file(p)["size"], 0)


if __name__ == "__main__":
    unittest.main()
